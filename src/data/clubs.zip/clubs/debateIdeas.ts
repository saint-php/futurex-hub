// src/data/clubs/debateIdeas.ts
import type { ClubIdea } from "./types";

export const debateIdeas: ClubIdea[] = [
  {
    id: "debate-001",
    category: "debate",
    title: "Complete Debate Starter Kit",
    summary:
      "Learn the principles of debate, how to structure arguments, and practice with ready-made topics.",
    description:
      "This is a full training pack for any Debate Club. It teaches the foundations and gives ready-to-use motions with points for both sides.",
    steps: [
      "Study the principles together as a club",
      "Practice the 'How to Debate' structure",
      "Choose one motion from the list",
      "Divide into Proposition and Opposition",
      "Prepare for 15–20 minutes",
      "Hold a structured debate",
      "Give feedback using the principles",
    ],
    materials: ["Notebooks", "Timer", "Printed motions (optional)"],
    safetyPrecautions: [
      "Keep debates respectful — attack ideas, never people",
      "Moderator must control time and tone",
      "Encourage quieter members to speak",
      "Avoid highly sensitive religious or tribal topics at the beginning",
    ],
    difficulty: "Medium",
    ageGroup: "13-18",
    timeNeeded: "Ongoing",
    xpReward: 50,
    coinReward: 25,
    tags: ["public speaking", "critical thinking", "training"],
    icon: "🎤",
    debateGuide: {
      principles: [
        "Respect your opponent at all times",
        "Attack the argument, never the person",
        "Use facts, logic and examples",
        "Listen carefully so you can rebut properly",
        "Stay calm even when challenged",
        "Structure your speech: Opening → Points → Conclusion",
        "Teamwork matters — support your side",
      ],
      howToDebate: [
        "1. Understand the motion clearly",
        "2. Decide if you are Proposition (support) or Opposition (against)",
        "3. Brainstorm 3 strong points",
        "4. Find examples or evidence for each point",
        "5. Prepare a short opening statement",
        "6. During the debate: present points clearly, then rebut the other side",
        "7. End with a strong summary",
        "8. Never interrupt rudely — wait for your turn",
      ],
      topics: [
        {
          motion: "Homework should be optional in secondary schools",
          propositionPoints: [
            "Homework causes unnecessary stress and reduces family time",
            "Quality of learning in class is more important than quantity at home",
            "Many students copy homework, so it does not show real understanding",
          ],
          oppositionPoints: [
            "Homework reinforces what was taught in class",
            "It builds discipline and independent study habits",
            "It helps teachers know which students need extra help",
          ],
          writeUp:
            "This motion asks whether forced homework is still useful. Proposition will argue that it harms wellbeing and often becomes meaningless copying. Opposition will argue that regular practice is essential for mastery and character development.",
        },
        {
          motion: "Social media does more harm than good to teenagers",
          propositionPoints: [
            "It increases anxiety, comparison and cyberbullying",
            "It reduces face-to-face social skills and sleep",
            "Addictive design wastes study time",
          ],
          oppositionPoints: [
            "It helps students access educational content and opportunities",
            "It allows connection with distant family and friends",
            "Used wisely, it builds digital skills needed in the modern world",
          ],
          writeUp:
            "A balanced debate about the real impact of social media on young people. Both sides must use examples from daily life.",
        },
        {
          motion: "School uniforms should be abolished",
          propositionPoints: [
            "Uniforms suppress individuality and self-expression",
            "They are an extra cost for many parents",
            "Students should learn to dress appropriately without being forced",
          ],
          oppositionPoints: [
            "Uniforms reduce peer pressure and visible inequality",
            "They create a sense of belonging and discipline",
            "They make it easier to identify students and improve security",
          ],
          writeUp:
            "A classic motion that trains students to argue about identity, equality and practicality.",
        },
        {
          motion: "Online learning can fully replace traditional classrooms",
          propositionPoints: [
            "It allows learning at your own pace and from anywhere",
            "It can be cheaper and more flexible",
            "Technology can personalise education better than one teacher",
          ],
          oppositionPoints: [
            "Face-to-face interaction develops social and emotional skills",
            "Not all students have reliable internet or devices",
            "Practical subjects and lab work are very difficult online",
          ],
          writeUp:
            "This motion forces students to think about the future of education and the limits of technology.",
        },
        // ===== NEW TOPICS START HERE =====
        {
          motion: "Secondary school students should be allowed to use phones in school",
          propositionPoints: [
            "Phones can be powerful learning tools when used properly",
            "Students need to stay in contact with parents for safety",
            "Banning phones does not teach responsible use",
          ],
          oppositionPoints: [
            "Phones cause major distraction during lessons",
            "They increase cyberbullying and social pressure",
            "Many students do not yet have the discipline to use them wisely",
          ],
          writeUp:
            "This motion examines whether the benefits of phones in school outweigh the clear problems of distraction and misuse.",
        },
        {
          motion: "Corporal punishment should be completely banned in schools",
          propositionPoints: [
            "It can cause physical and emotional harm",
            "There are better ways to discipline students",
            "It teaches that violence is an acceptable solution",
          ],
          oppositionPoints: [
            "Some students only respond to firm physical correction",
            "When used mildly and fairly it can maintain order",
            "Complete ban may lead to worse behavioural problems",
          ],
          writeUp:
            "A sensitive but important motion. Debaters must stay respectful and focus on evidence rather than personal emotion.",
        },
        {
          motion: "Boarding schools are better than day schools",
          propositionPoints: [
            "They teach independence and life skills",
            "Students have more time for studies and structured activities",
            "They reduce long daily travel and distractions from home",
          ],
          oppositionPoints: [
            "Young people need daily family connection",
            "Homesickness and lack of privacy can affect mental health",
            "Day schools allow students to learn responsibility at home too",
          ],
          writeUp:
            "This motion helps students think about independence, family, and the best environment for learning.",
        },
        {
          motion: "The voting age should be lowered to 16",
          propositionPoints: [
            "16-year-olds already pay taxes in some cases and can work",
            "It would increase youth interest in politics and governance",
            "Many 16-year-olds are informed and mature enough",
          ],
          oppositionPoints: [
            "Many 16-year-olds still lack life experience",
            "They may be more easily influenced by trends and social media",
            "Legal adulthood and full responsibility come at 18 for good reasons",
          ],
          writeUp:
            "A forward-looking motion that trains students to discuss citizenship, maturity and rights.",
        },
        {
          motion: "Homework does more harm than good",
          propositionPoints: [
            "It causes stress and reduces time for rest and family",
            "Many students copy it, so it fails its purpose",
            "Good teaching in school should be enough",
          ],
          oppositionPoints: [
            "Practice is necessary for mastery of difficult subjects",
            "It builds discipline and independent learning",
            "It helps teachers identify who needs extra support",
          ],
          writeUp:
            "A classic student-friendly motion that always generates strong arguments on both sides.",
        },
      ],
    },
  },
];